from Live import load_game, welcome

name = input("Please enter your name: ")
print(welcome(name))
load_game()

# print(welcome("Moshe"))
# load_game()
